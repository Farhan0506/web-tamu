
<?php
// memanggil fungsi.php 
require 'Koneksi.php';

// Prepare statement menghapus data di table barang berdasarkan id barang 
$stmt = $mysqli->prepare("DELETE FROM buku_tamu WHERE id =?");

// bind param 
$stmt->bind_param("i", $_GET['id']);
// pesan jika berhasil dan gagal 
if ($stmt->execute()) {
    echo "<div class='alert alert-success'>Data Tamu Berhasil dihapus. 
    <a href='index.php'>Kembali ke List Barang</a></div>";
} else {
    echo "<div class='alert alert-danger'>Data Tamu Gagal dihapus..!. Silahkan Coba Lagi.</div>";
}

// clsoe prepare statement
$stmt->close();

// close connection
$mysqli->close();
