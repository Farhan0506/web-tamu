<?php
// memamggil fungsi koneksi.php ke database 
require 'Koneksi.php';

// jika tombol submit di tekan 
if (isset($_POST['btnSubmit'])) {

    // menambil data yang di input dar $_POST
    $nama = $mysqli->real_escape_string($_POST['nama']);
    $instansi = $mysqli->real_escape_string($_POST['instansi']);
    $tujuan = $mysqli->real_escape_string($_POST['tujuan']);
    $tanggal = $mysqli->real_escape_string($_POST['tanggal']);
    $waktu = $mysqli->real_escape_string($_POST['waktu']);

    // Prepared statement untuk update tabel barang berdasarkan id Tamu 
    $stmt = $mysqli->prepare("UPDATE buku_tamu SET nama=?, instansi=?, tujuan=? , tanggal=? ,waktu=? WHERE id=?");

    // Bind params
    $stmt->bind_param("sssssi", $nama, $instansi, $tujuan, $tanggal, $waktu, $_GET['id']);

    // Execute query
    if ($stmt->execute()) {
        $alert_message = "Data Tamu berhasil di Edit.";
    } else {
        $alert_message = "Gagal Edit Data Tamu. Silahkan dicoba Lagi.";
    }

    // Close prepare statement
    $stmt->close();
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Buku Tamu - Dashboard</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.php">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Buku Tamu </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Dashboard -->
            <li class="nav-item active">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Dashboard</span></a>
            </li>

            <!-- Nav Item - Tables -->
            <li class="nav-item">
                <a class="nav-link" href="daftarbukutamu.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Daftar Buku Tamu</span></a>
            </li>

            <!-- Nav Item - Charts -->
            <li class="nav-item">
                <a class="nav-link" href="formulirdatatamu.php">
                    <i class="fas fa-fw fa-chart-area"></i>
                    <span>Formulir Data Tamu</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>


        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <table width="70%" cellpadding="2" cellspacing="2" align="center" style="margin-top:20px;">
                        <tr>
                            <td align="center">
                                <h2>Edit Data Tamu</h2>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <?php
                                if (isset($alert_message) and !empty($alert_message)) {
                                    echo "<div class='alert alert-success'>" . $alert_message . "</div>";
                                }
                                ?>

                                <?php
                                // ambil Data Tamu berdasarka ID Tamu
                                $stmt = $mysqli->prepare("SELECT id, nama, instansi, tujuan, tanggal, waktu FROM buku_tamu WHERE id = ?");
                                $stmt->bind_param("i", $_GET['id']);
                                $stmt->execute();
                                $stmt->store_result();
                                if ($stmt->num_rows == 1) {
                                    $stmt->bind_result($id, $nama, $instansi, $tujuan, $tanggal, $waktu);
                                    $stmt->fetch();
                                ?>
                                    <form method="post">
                                        <table width="60%" cellpadding="5" cellspacing="5" align="center">
                                            <tr>
                                                <td style="width:30%">Nama:</td>
                                                <td><input required type="text" class="form-control" name="nama" style="width:100%;" placeholder="Isikan Nama Barang" value="<?= $nama ?>" </td>
                                            </tr>
                                            <tr>
                                                <td style="width:30%">Instasi:</td>
                                                <td><input required type="text" class="form-control" name="instansi" style="width:100%;" placeholder="Isi Kategori Barang" value="<?= $instansi ?>" </td>
                                            </tr>
                                            <tr>
                                                <td style="width:30%">Tujuan:</td>
                                                <td><input required type="text" class="form-control" name="tujuan" style="width:100%;" placeholder="Isi Tujuan" value="<?= $tujuan ?>" </td>
                                            </tr>
                                            <tr>
                                                <td style="width:30%">Tanggal:</td>
                                                <td><input required type="date" class="form-control" name="tanggal" style="width:100%;" placeholder="isi Tanggal" value="<?= $tanggal ?>" readonly </td>
                                            </tr>
                                            <tr>
                                                <td style=" width:30%">Waktu:</td>
                                                <td><input required type="time" class="form-control" name="waktu" style="width:100%;" placeholder="isi Waktu" value="<?= $waktu ?>" readonly</td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    <button type="submit" name="btnSubmit" class="btn btn-primary">Submit</button>
                                                    <a href="index.php" class="btn btn-info">Kembali ke Daftar Tamu</a>
                                                </td>
                                            </tr>
                                        </table>
                                    </form>
                                <?php } else {
                                    echo "Invalid Id Tamu";
                                } ?>
                            </td>
                        </tr>
                    </table>

                    <!-- Content Row -->

                    <div class="row">


                    </div>

                    <!-- Content Row -->
                    <div class="row">


                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2021</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>



</body>

</html>